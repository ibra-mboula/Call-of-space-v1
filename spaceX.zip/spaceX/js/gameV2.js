// 

var config = {
    type: Phaser.AUTO,
    width: 700,
    height: 700,
/*    physics: {
        default: 'arcade'
    },*/
    scene: {
        preload : preload,     
        create: create,     
        update : update   
    }
};

const game = new Phaser.Game(config);

function preload() {
    //pour charger l'image this.load.image ; puis il faut 
    //donner une clés a cette immage <player> ; indiquer ou 
    //se trouve l'image
  this.load.image('player' ,'./assets/images/plane1.png');
  
    this.load.image('background1' ,'./assets/images/background1.png');
}

function create() {
 
 var backgroundImage = this.add.sprite(0,0,'background1'); //pour afficher une image 
  backgroundImage.setOrigin(0.0) ;  /*pour ramener l'origine en haaut a gauche de la page definit*/
  //backgroundImage.setposition(config.width/2 , config.height/2);//pour centrer l'image 
  backgroundImage.setScale(0.75) ;   /*pour modofoer la taille de l'image*/
 var player = this.add.sprite(150,150,'player');
 player.setScale(0.3);
}

function update(time,delta) {
    
}
