
var config = {
  type: Phaser.AUTO,
  width: 1300,
  height: 550,

  scene: {
    preload: preload,
    create: create,
    update: update
  },

  physics: {
    default: "arcade",
    arcade: {
      debug: false,
      gravity: { y: 0 }
    }
  }
}


const game = new Phaser.Game(config);

var player;// création de la var qui va contenir le player
var cursor; // pour les deplacement du perso

var score = 0;
var scoreText;




function preload() {
  //pour charger l'image this.load.image ; puis il faut 
  //donner une clés a cette immage <player> ; indiquer ou 
  //se trouve l'image
  this.load.image('player', './assets/images/plane1right.png');
  this.load.image('background', './assets/images/background.png');
  this.load.image('moon', './assets/images/moon.png');
  this.load.image('satelite', './assets/images/satelite.png');
  this.load.image('cloud', './assets/images/cloud.png');

  this.load.image('obstacle1', './assets/images/obstacle1.png');
  this.load.image('obstacle2', './assets/images/obstacle2.png');

  this.load.image('Rockets1', './assets/images/Rockets1.png');
  this.load.image('Rockets2', './assets/images/Rockets2.png');
  this.load.image('Rockets3', './assets/images/Rockets3.png');
  this.load.image('Rockets4', './assets/images/Rockets4.png');
  this.load.image('goku', './assets/images/goku.png');
  this.load.image('sgoku', './assets/images/sgoku.png');

  this.load.image('roue', './assets/images/roue.png');


  this.load.image('Gold', './assets/images/Gold.png');

  this.load.image('ground0', './assets/images/ground0.png');
  this.load.image('rock1', './assets/images/rock1.png');
  this.load.image('rock3', './assets/images/rock3.png');
  this.load.image('cloud', './assets/images/cloud.png');
  this.load.image('platform', './assets/images/platform.png');

  this.load.image('star', './assets/images/star.png');




  //this.load.image('tiles' ,'./assets/images/platformPack_tilesheet.png');
  //this.load.tilemapTiledJSON('map' ,'./assets/json/sky1.json');
  // this.load.audio("start",'./assets/audio/start.ogg');

}

function create() {



  //this.audio.play("start");
  //player.body.collideWorldBounds = true ; 
  //----------------------------------------------------------------------------
  //this.tilemap = this.make.tilemap({key: "map"});
  //this.tileset = this.tilemap.addTilesetImage("platformPack_tilesheet","tiles")

  //this.downLayer = this.tilemap.createStaticLayer("top",this.tileset,0,0);
  //this.downLayer = this.tilemap.createStaticLayer("world",this.tileset,0,0);
  //this.downLayer = this.tilemap.createStaticLayer("bot",this.tileset,0,0);*/

  cursor = this.input.keyboard.createCursorKeys();//direction du perso



  var backgroundImage = this.add.sprite(0, 0, 'background'); //pour afficher une image 
  backgroundImage.setOrigin(0.0);  /*pour ramener l'origine en haaut a gauche de la page definit*/
  //backgroundImage.setposition(config.width/2 , config.height/2);//pour centrer l'image 
  backgroundImage.setScale(0.75);  /*pour modifier la taille de l'image*/



  // Ajout d'un perso sans physique --> var player = this.add.sprite(150,150,'player');



  player = this.physics.add.sprite(25, 60, 'player'); //un player avec de la physique
  player.setScale(0.3);// modifier les dimensions de notre player 
  player.body.setSize(100, 100);// ajuster le cadre de l'image pour une best interaction 


  //deplacement obstacle
  //-----------------------------------------------------------------------
  var enemy1 = this.physics.add.sprite(400, 240, "roue");
  enemy1.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy1,
    x: 1000,
    ease: "Linear",
    duration: 3000,
    yoyo: true,
    repeat: -1,

  });

  



  var enemy2 = this.physics.add.sprite(1500, 100, "Rockets1");
  enemy2.setScale(0.08);
  var tween = this.tweens.add({
    targets: enemy2,
    x: -300,
    ease: "Linear",
    duration: 5500,
    yoyo: false,
    repeat: 5,

  });

  var enemy3 = this.physics.add.sprite(1500, 400, "sgoku");
  enemy3.setScale(0.06);
  var tween = this.tweens.add({
    targets: enemy3,
    x: -300,
    ease: "Linear",
    duration: 4500,
    yoyo: false,
    repeat: 3,

  });

  var enemy4 = this.physics.add.sprite(1500, 300, "Rockets3");
  enemy4.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy4,
    x: -300,
    ease: "Linear",
    duration: 7000,
    yoyo: false,
    repeat: 10,

  });

  var enemy5 = this.physics.add.sprite(1500, 500, "roue");
  enemy5.setScale(0.15);
  var tween = this.tweens.add({
    targets: enemy5,
    x: -300,
    ease: "Linear",
    duration: 7500,
    yoyo: false,
    repeat: 15,

  });

  var enemy6 = this.physics.add.sprite(1500, 400, "roue");
  enemy6.setScale(0.15);
  var tween = this.tweens.add({
    targets: enemy6,
    x: -300,
    ease: "Linear",
    duration: 6200,
    yoyo: false,
    repeat: 16,

  });

  var enemy7 = this.physics.add.sprite(1500, 50, "Rockets2");
  enemy7.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy7,
    x: -300,
    ease: "Linear",
    duration: 6200,
    yoyo: false,
    repeat: 18,

  });



  var enemy8 = this.physics.add.sprite(1500, 350, "Rockets2");
  enemy8.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy8,
    x: -300,
    ease: "Linear",
    duration: 10000,
    yoyo: false,
    repeat: 18,

  });

  var enemy9 = this.physics.add.sprite(1500, 330, "Rockets3");
  enemy9.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy9,
    x: -300,
    ease: "Linear",
    duration: 4000,
    yoyo: false,
    repeat: 18,

  });

  var enemy10 = this.physics.add.sprite(1500, 200, "Rockets3");
  enemy10.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy10,
    x: -300,
    ease: "Linear",
    duration: 3000,
    yoyo: false,
    repeat: 18,

  });

  var enemy11 = this.physics.add.sprite(1500, 200, "Rockets3");
  enemy11.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy11,
    x: -300,
    ease: "Linear",
    duration: 6000,
    yoyo: false,
    repeat: 18,

  });

  var enemy12 = this.physics.add.sprite(1500, 150, "Rockets2");
  enemy12.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy12,
    x: -300,
    ease: "Linear",
    duration: 2500,
    yoyo: false,
    repeat: 18,

  });

  var enemy13 = this.physics.add.sprite(1500, 330, "Rockets4");
  enemy13.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy13,
    x: -300,
    ease: "Linear",
    duration: 3500,
    yoyo: false,
    repeat: 18,

  });



  var enemy14 = this.physics.add.sprite(1500, 500, "Rockets1");
  enemy14.setScale(0.08);
  var tween = this.tweens.add({
    targets: enemy14,
    x: -300,
    ease: "Linear",
    duration: 3500,
    yoyo: false,
    repeat: 18,

  });

  var enemy15 = this.physics.add.sprite(1500, 300, "Rockets1");
  enemy15.setScale(0.08);
  var tween = this.tweens.add({
    targets: enemy15,
    x: -300,
    ease: "Linear",
    duration: 5000,
    yoyo: false,
    repeat: 18,

  });

  var enemy16 = this.physics.add.sprite(1500, 20, "Rockets3");
  enemy16.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy16,
    x: -300,
    ease: "Linear",
    duration: 3500,
    yoyo: false,
    repeat: 18,

  });


  //------------------------------------------------------------------



  var platforms = this.physics.add.staticGroup();



  //var ground0 = this.add.sprite(25,300,'ground0');
  // ground0.setScale(0.75);


  //var ground1 = this.add.sprite(625,650,'rock3');
  //ground1.setScale(2);


  var ground2 = this.add.sprite(620, 525, 'obstacle1');
  ground2.setScale();



  var moon = this.add.sprite(1200, 50, 'moon');
  moon.setSize(50, 50);


  player.setCollideWorldBounds(true);


  platforms.add(ground2);
  platforms.add(moon);


  //this.physics.add.collider(player, enemy1);
  //this.physics.add.collider(enemy1, player);





  this.physics.add.collider(platforms, player);
  //this.physics.add.collider(,player) ;

  /////


  var stars = this.physics.add.sprite(200, 400, "star");
  stars.setScale(0.6);
  var tween = this.tweens.add({
    targets: stars,
    x: 500,
    ease: "Linear",
    duration: 4000,
    yoyo: true,
    repeat: -1,

  });

  //////////////////////************************ 
  var star1 = this.physics.add.sprite(1500, 360, "star");
  star1.setScale(0.6);
  var tween = this.tweens.add({
    targets: star1,
    x: -300,
    ease: "Linear",
    duration: 2500,
    yoyo: false,
    repeat: 18,

  });

  var star2 = this.physics.add.sprite(1500, 200, "star");
  star2.setScale(0.6);
  var tween = this.tweens.add({
    targets: star2,
    x: -300,
    ease: "Linear",
    duration: 2600,
    yoyo: false,
    repeat: 18,

  });

  var star3 = this.physics.add.sprite(1500, 400, "star");
  star3.setScale(0.6);
  var tween = this.tweens.add({
    targets: star3,
    x: -300,
    ease: "Linear",
    duration: 9000,
    yoyo: false,
    repeat: 18,

  });

  var star4 = this.physics.add.sprite(1500, 100, "star");
  star4.setScale(0.6);
  var tween = this.tweens.add({
    targets: star4,
    x: -300,
    ease: "Linear",
    duration: 3000,
    yoyo: false,
    repeat: 18,

  });

  var star5 = this.physics.add.sprite(1100, 500, "star");
  star5.setScale(0.6);


  this.physics.add.overlap(player, stars, collectStar, null, this);
  this.physics.add.overlap(player, star1, collectStar, null, this);
  this.physics.add.overlap(player, star2, collectStar, null, this);
  this.physics.add.overlap(player, star3, collectStar, null, this);
  this.physics.add.overlap(player, star4, collectStar, null, this);
  this.physics.add.overlap(player, star5, collectStar, null, this);


  scoreText = this.add.text(13, 500, 'Star: 0', { fontSize: '25px', fill: '#000' });

  //this.physics.add.overlap(Player,enemy1, restart);

}



function collectStar(player, star) {
  star.disableBody(true, true);

  score += 1;
  scoreText.setText('Star: ' + score);
}
function restart (Player, enemy1){
  Perso.setPosition(100,100);
  
}
function startGame() {
  titleScreen.setVisible(false);
  startButton.setVisible(false);
 
}

function update(time, delta) {


  // obstacle2.setAngle(obstacle2.angle + 1) ;
  deplacement()

}
//------------------------------------------------------------------

function deplacement() {


  if (cursor.left.isDown) {
    //pour verifier dans la console si gauche fonctionne bien --> console.log("gauche");

    player.setVelocityX(-250);
    player.setFlip(true, false);

  }

  if (cursor.right.isDown) {

    player.setVelocityX(250);

    player.setFlip(false, false);
  }

  if (cursor.up.isDown) {

    player.setVelocityY(-250);

  }

  if (cursor.down.isDown) {

    player.setVelocityY(250);

  }


  if (cursor.right.isUp && cursor.left.isUp) {
    player.setVelocityX(0);
  }

  if (cursor.up.isUp && cursor.down.isUp) {
    player.setVelocityY(0);
  }
}

