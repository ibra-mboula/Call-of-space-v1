
var config = {
    type: Phaser.AUTO,
    width: 1300,
    height: 500,

    scene: {
        preload : preload,     
        create: create,     
        update : update   
    },

    physics : {
        default : "arcade",
        arcade : {
            debug : true,
            gravity : {y :10}
        }
    }
}


const game = new Phaser.Game(config);

var player ;// création de la var qui va contenir le player
var cursor ; // pour les deplacement du perso




function preload() {
    //pour charger l'image this.load.image ; puis il faut 
    //donner une clés a cette immage <player> ; indiquer ou 
    //se trouve l'image
  this.load.image('player' ,'./assets/images/plane1right.png');
  this.load.image('background' ,'./assets/images/background.png');
  this.load.image('obstacle1' ,'./assets/images/obstacle1.png');
  this.load.image('obstacle2' ,'./assets/images/obstacle2.png');
  this.load.image('ground0' ,'./assets/images/ground0.png');

  this.load.image('tiles' ,'./assets/images/platformPack_tilesheet.png');
  this.load.tilemapTiledJSON('map' ,'./assets/json/sky1.json');
 // this.load.audio("start",'./assets/audio/start.ogg');

}

function create() {

//this.audio.play("start");
//player.body.collideWorldBounds = true ,  
//----------------------------------------------------------------------------
/*this.tilemap = this.make.tilemap({key: "map"});
this.tileset = this.tilemap.addTilesetImage("platformPack_tilesheet","tiles")

this.downLayer = this.tilemap.createStaticLayer("top",this.tileset,0,0);
this.downLayer = this.tilemap.createStaticLayer("world",this.tileset,0,0);
this.downLayer = this.tilemap.createStaticLayer("bot",this.tileset,0,0);*/

    cursor = this.input.keyboard.createCursorKeys();//direction du perso

    

 var backgroundImage = this.add.sprite(0,0,'background'); //pour afficher une image 
   backgroundImage.setOrigin(0.0) ;  /*pour ramener l'origine en haaut a gauche de la page definit*/
   //backgroundImage.setposition(config.width/2 , config.height/2);//pour centrer l'image 
   backgroundImage.setScale(1.7) ;  /*pour modifier la taille de l'image*/

   

  // Ajout d'un perso sans physique --> var player = this.add.sprite(150,150,'player');



 player = this.physics.add.sprite(25,60,'player'); //un player avec de la physique
 player.setScale(0.3);// modifier les dimensions de notre player 
 player.body.setSize(100,100);// ajuster le cadre de l'image pour une best interaction 



 var enemy1 = this.add.sprite(400,200,"obstacle2");
 enemy1.setScale(0.3);
 var tween = this.tweens.add({
   targets : enemy1,
   x : 1000,
   ease : "Linear",
   duration : 3000,
   yoyo : true,
   repeat : -1,
   
 });


 var platforms = this.physics.add.staticGroup();


 


var ground0 = this.add.sprite(25,200,'ground0');
  ground0.setScale(0.75);
  //ground0.setAngle(45);
  //ground0.setAngle(ground0.angle + 1);

var ground1 = this.add.sprite(100,400,'ground0');
 ground1.setScale(0.75);



var obstacle1 = this.add.sprite(500,100,'obstacle1');
 //obstacle1.setScale(0.3);
 obstacle1.setSize(100,100);

 //var obstacle2 = this.add.sprite(400,300,'obstacle1');
 // obstacle2.setScale(0.4);
 //obstacle2.setOrigin(0,0);
 // obstacle2.setSize(10,100);
     
  platforms.add(ground0)  ;
  platforms.add(ground1) ;
  platforms.add(obstacle1) ;
 


 

  this.physics.add.collider(platforms,player) ;


}

function update(time,delta) {

    
  // obstacle2.setAngle(obstacle2.angle + 1) ;
  deplacement()
  
}
//------------------------------------------------------------------

function deplacement(){

    
if(cursor.left.isDown){
    //pour verifier dans la console si gauche fonctionne bien --> console.log("gauche");

    player.setVelocityX(-100);
    player.setFlip(true,false);
     
 }

if(cursor.right.isDown){
   
     player.setVelocityX(100);
     player.setFlip(false,false);
  }

if(cursor.up.isDown){
   
     player.y -= 1 ;
     
  }

if(cursor.down.isDown){
   
 player.y += 1 ;  
     
  }
  

if(cursor.right.isUp && cursor.left.isUp ){
     player.setVelocityX(0);  
  }
}