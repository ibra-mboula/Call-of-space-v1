// squelette de base pour crée mon jeux phaser

var config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
/*    physics: {
        default: 'arcade'
    },*/
    scene: {
        preload : preload,     
        create: create,     
        update : update   
    }
};

const game = new Phaser.Game(config);

function preload() {
    
}

function create() {
    monTimer = this.time.addEvent({
        delay: 1000,
        callback: compteUneSeconde,
        callbackScope: this,
        loop: true
      
        
      });
    
    
    chronoText = this.add.text(60, 400, "Chrono: 0", {
      fontSize: "24px",
      fill: "#FFFFFF" //Couleur de l'écriture
    });
    chronoText.setScrollFactor(0);
    
}
function compteUneSeconde () {
    chrono= chrono+1; // on incremente le chronometre d'une unite
    chronoText.setText("Chrono: "+ chono); // mise à jour de l'affichage
  }  
function update(time,delta) {
    
}
