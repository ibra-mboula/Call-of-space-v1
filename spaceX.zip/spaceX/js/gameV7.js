
var config = {
  type: Phaser.AUTO,
  width: 1280,
  height: 550,

  scene: {
    preload: preload,
    create: create,
    update: update
  },

  physics: {
    default: "arcade",
    arcade: {
      debug: false,
      gravity: { y: 0 }
    }
  }
}


const game = new Phaser.Game(config);

var player;// création de la var qui va contenir le player
var cursor; // pour les deplacement du perso

var score = 0;
var scoreText;
var end ;
var text;
var win ;

var counter = 0;
var text = 0; 

var chronoTexte;
var monTimer;
var chrono = 0;
var munition ;
var boumBouton;
var start;
var naruto ;
var kira;

function preload() {
 
  this.load.image('player', './assets/images/plane1right.png');
  this.load.image('background', './assets/images/background.png');
  this.load.image('moon', './assets/images/moon.png');


  this.load.image('obstacle1', './assets/images/obstacle1.png');


  this.load.image('Rockets1', './assets/images/Rockets1.png');
  this.load.image('Rockets2', './assets/images/Rockets2.png');
  this.load.image('Rockets3', './assets/images/Rockets3.png');
  this.load.image('Rockets4', './assets/images/Rockets4.png');
 
  this.load.image('sgoku', './assets/images/sgoku.png');

  this.load.image('roue', './assets/images/roue.png');


  this.load.image('end', './assets/images/end.jpeg');
  this.load.image('debut', './assets/images/debut.jpg');
  this.load.image('play', './assets/images/play.png');
  this.load.image('win', './assets/images/win.jpg');


  this.load.image('star', './assets/images/star.png');
  this.load.image('tire', './assets/images/Munition.png');
 this.load.image('tire', './assets/images/Munition.png');
  this.load.audio('naruto', './assets/audio/naruto.ogg');

  this.load.audio('start', './assets/audio/start.ogg');
  this.load.audio('kira', './assets/audio/kira.ogg');
  //this.load.image('tiles' ,'./assets/images/platformPack_tilesheet.png');
  //this.load.tilemapTiledJSON('map' ,'./assets/json/sky1.json');
  // this.load.audio("start",'./assets/audio/start.ogg');

}

function create() {
  
naruto = this.sound.add('naruto');
naruto.play();
  
start = this.sound.add('start');
kira =  this.sound.add('kira');


  //----------------------------------------------------------------------------
  //this.tilemap = this.make.tilemap({key: "map"});
  //this.tileset = this.tilemap.addTilesetImage("platformPack_tilesheet","tiles")

  //this.downLayer = this.tilemap.createStaticLayer("top",this.tileset,0,0);
  //this.downLayer = this.tilemap.createStaticLayer("world",this.tileset,0,0);
  //this.downLayer = this.tilemap.createStaticLayer("bot",this.tileset,0,0);*/

  cursor = this.input.keyboard.createCursorKeys();//direction du perso



  var backgroundImage = this.add.sprite(0, 0, 'background'); //pour afficher une image 
  backgroundImage.setOrigin(0.0);  /*pour ramener l'origine en haaut a gauche de la page definit*/
  //backgroundImage.setposition(config.width/2 , config.height/2);//pour centrer l'image 
  backgroundImage.setScale(0.75);  /*pour modifier la taille de l'image*/

 
  // Ajout d'un perso sans physique --> var player = this.add.sprite(150,150,'player');

 

  player = this.physics.add.sprite(25, 60, 'player'); //un player avec de la physique
  player.setScale(0.3);// modifier les dimensions de notre player 
  player.body.setSize(100, 100);// ajuster le cadre de l'image pour une best interaction 


  //deplacements obstacles  :(
  //-----------------------------------------------------------------------
  var enemy1 = this.physics.add.sprite(400, 240, "roue");
  enemy1.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy1,
    x: 1000,
    ease: "Linear",
    duration: 3000,
    yoyo: true,
    repeat: -1,

  });


  var enemy2 = this.physics.add.sprite(1500, 280, "Rockets1");
  enemy2.setScale(0.06);
  var tween = this.tweens.add({
    targets: enemy2,
    x: -300,
    ease: "Linear",
    duration: 5500,
    yoyo: false,
    repeat: 500,

  });

  var enemy3 = this.physics.add.sprite(500, 100, "sgoku");
  enemy3.setScale(0.06);
  var tween = this.tweens.add({
    targets: enemy3,
    x: 1700,
    ease: "Linear",
    duration: 3000,
    yoyo: true,
    repeat: -1,

  });

  var enemy4 = this.physics.add.sprite(1500, 300, "Rockets3");
  enemy4.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy4,
    x: -300,
    ease: "Linear",
    duration: 7000,
    yoyo: false,
    repeat: 100,

  });

  var enemy5 = this.physics.add.sprite(1500, 500, "roue");
  enemy5.setScale(0.15);
  var tween = this.tweens.add({
    targets: enemy5,
    x: -300,
    ease: "Linear",
    duration: 7500,
    yoyo: false,
    repeat: 150,

  });

  var enemy6 = this.physics.add.sprite(1500, 400, "roue");
  enemy6.setScale(0.15);
  var tween = this.tweens.add({
    targets: enemy6,
    x: -300,
    ease: "Linear",
    duration: 6200,
    yoyo: false,
    repeat: 106,

  });

  var enemy7 = this.physics.add.sprite(1500, 350, "Rockets2");
  enemy7.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy7,
    x: -300,
    ease: "Linear",
    duration: 6200,
    yoyo: false,
    repeat: 180,

  });



  var enemy8 = this.physics.add.sprite(1500, 350, "Rockets2");
  enemy8.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy8,
    x: -300,
    ease: "Linear",
    duration: 10000,
    yoyo: false,
    repeat: 180,

  });

  var enemy9 = this.physics.add.sprite(1500, 330, "Rockets3");
  enemy9.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy9,
    x: -300,
    ease: "Linear",
    duration: 4000,
    yoyo: false,
    repeat: 180,

  });

  var enemy10 = this.physics.add.sprite(1500, 200, "Rockets3");
  enemy10.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy10,
    x: -300,
    ease: "Linear",
    duration: 3000,
    yoyo: false,
    repeat: 180,

  });

  var enemy11 = this.physics.add.sprite(1500, 200, "Rockets3");
  enemy11.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy11,
    x: -300,
    ease: "Linear",
    duration: 6000,
    yoyo: false,
    repeat: 180,

  });

  var enemy12 = this.physics.add.sprite(1500, 150, "Rockets2");
  enemy12.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy12,
    x: -300,
    ease: "Linear",
    duration: 2500,
    yoyo: false,
    repeat: 180,

  });

  var enemy13 = this.physics.add.sprite(1500, 330, "Rockets4");
  enemy13.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy13,
    x: -300,
    ease: "Linear",
    duration: 3500,
    yoyo: false,
    repeat: 180,

  });



  var enemy14 = this.physics.add.sprite(1500, 500, "Rockets1");
  enemy14.setScale(0.08);
  var tween = this.tweens.add({
    targets: enemy14,
    x: -300,
    ease: "Linear",
    duration: 3500,
    yoyo: false,
    repeat: 180,

  });

  var enemy15 = this.physics.add.sprite(1500, 300, "Rockets1");
  enemy15.setScale(0.08);
  var tween = this.tweens.add({
    targets: enemy15,
    x: -300,
    ease: "Linear",
    duration: 5000,
    yoyo: false,
    repeat: 180,

  });

  var enemy16 = this.physics.add.sprite(1500, 20, "Rockets3");
  enemy16.setScale(0.2);
  var tween = this.tweens.add({
    targets: enemy16,
    x: -300,
    ease: "Linear",
    duration: 3500,
    yoyo: false,
    repeat: 180,

  });

  tire = this.physics.add.group();
  boumBouton = this.input.keyboard.addKey('space');
  this.physics.add.overlap(tire, enemy1, boum) ;
  this.physics.add.overlap(tire, enemy2, boum);
  this.physics.add.overlap(tire, enemy5, boum);
  this.physics.add.overlap(tire, enemy6, boum);
  this.physics.add.overlap(tire, enemy14, boum);
  this.physics.add.overlap(tire, enemy15, boum);
  


  //------------------------------------------------------------------



  var platforms = this.physics.add.staticGroup();

  var ground2 = this.add.sprite(25, 95, 'obstacle1');
  ground2.setScale();

  var moon = this.add.sprite(1200, 50, 'moon');
  moon.setSize(50, 50);

  player.setCollideWorldBounds(true);


  platforms.add(ground2);
  platforms.add(moon);


  this.physics.add.collider(platforms, player);

  var stars = this.physics.add.sprite(200, 400, "star");
  stars.setScale(0.5);
  var tween = this.tweens.add({
    targets: stars,
    x: 500,
    ease: "Linear",
    duration: 4000,
    yoyo: true,
    repeat: -1,

  });

  //************************ 
  var star1 = this.physics.add.sprite(1500, 360, "star");
  star1.setScale(0.5);
  var tween = this.tweens.add({
    targets: star1,
    x: -300,
    ease: "Linear",
    duration: 2500,
    yoyo: false,
    repeat: 180,

  });

  var star2 = this.physics.add.sprite(1500, 200, "star");
  star2.setScale(0.5);
  var tween = this.tweens.add({
    targets: star2,
    x: -300,
    ease: "Linear",
    duration: 2600,
    yoyo: false,
    repeat: 180,

  });

  var star3 = this.physics.add.sprite(1500, 400, "star");
  star3.setScale(0.5);
  var tween = this.tweens.add({
    targets: star3,
    x: -300,
    ease: "Linear",
    duration: 9000,
    yoyo: false,
    repeat: 180,

  });

  var star4 = this.physics.add.sprite(1500, 100, "star");
  star4.setScale(0.5);
  var tween = this.tweens.add({
    targets: star4,
    x: -300,
    ease: "Linear",
    duration: 3000,
    yoyo: false,
    repeat: 180,

  });

  var star5 = this.physics.add.sprite(1000, 50, "star");
  star5.setScale(0.5);
  var star6 = this.physics.add.sprite(500, 100, "star");
  star6.setScale(0.5);
  var star7 = this.physics.add.sprite(650, 250, "star");
  star7.setScale(0.5);
  var star8 = this.physics.add.sprite(800, 300, "star");
  star8.setScale(0.5);
  var star9 = this.physics.add.sprite(1100, 400, "star");
  star9.setScale(0.5);
  var star10 = this.physics.add.sprite(900, 500, "star");
  star10.setScale(0.5);



  this.physics.add.overlap(player, stars, collectStar);
  this.physics.add.overlap(player, star1, collectStar);
  this.physics.add.overlap(player, star2, collectStar );
  this.physics.add.overlap(player, star3, collectStar );
  this.physics.add.overlap(player, star4, collectStar );
  this.physics.add.overlap(player, star5, collectStar );
  this.physics.add.overlap(player, star6, collectStar);
  this.physics.add.overlap(player, star7, collectStar);
  this.physics.add.overlap(player, star8, collectStar );
  this.physics.add.overlap(player, star9, collectStar );
  this.physics.add.overlap(player, star10,collectStar );
  


  scoreText = this.add.text(15, 480, 'Star : 0 /10', { fontSize: '25px', fill: '#FFFFFF' });
  

  
  this.physics.add.collider(player, enemy1, end, null, this);
  this.physics.add.collider(player, enemy2, end, null, this);
  this.physics.add.collider(player, enemy3, end, null, this);
  this.physics.add.collider(player, enemy4, end, null, this);
  this.physics.add.collider(player, enemy5, end, null, this);
  this.physics.add.collider(player, enemy6, end, null, this);
  this.physics.add.collider(player, enemy7, end, null, this);
  this.physics.add.collider(player, enemy8, end, null, this);
  this.physics.add.collider(player, enemy9, end, null, this);
  this.physics.add.collider(player, enemy10, end, null, this);
  this.physics.add.collider(player, enemy11, end, null, this);
  this.physics.add.collider(player, enemy12, end, null, this);
  this.physics.add.collider(player, enemy13, end, null, this);
  this.physics.add.collider(player, enemy14, end, null, this);
  this.physics.add.collider(player, enemy15, end, null, this);
  this.physics.add.collider(player, enemy16, end, null, this);
  
  
  end = this.add.image(0, 0, 'end');
  end.setOrigin(0, 0);
  end.setDisplaySize(1300,550);
  end.setVisible(false);
  

  win = this.add.image(0, 0, 'win');
  win.setOrigin(0, 0);
  win.setDisplaySize(1300,550);
  win.setVisible(false);


  titleScreen = this.add.image(0, 0, 'debut');
  titleScreen.setOrigin(0, 0);
  titleScreen.setScale(0.5);
  startButton = this.add.image(280, 250, 'play').setInteractive();
  startButton.setScale(0.4);
  
  startButton.on('pointerdown', startGame);
  
  let timer = this.time.addEvent({ 
    delay: 1000, // ms 
    callback: time, 
    callbackScope: this, 
    repeat: 1000
    
   });



  chronoText = this.add.text(15, 0, "Survival time: 0", { 
    fontSize: "18px",
    fill: "#FFFFFF" 
  });


}


function time() { 

  chrono = chrono + 1; 
        chronoText.setText("Survival time: " + chrono);

  } 
 

function collectStar(player, star) {
  star.disableBody(true, true);

  score += 1;
  scoreText.setText('Star: ' + score + "/10");

  if(score == 10){

    player.setTint(0xff0000);
    win.setVisible(true);
    naruto.stop();


  }

}

function startGame() {
  titleScreen.setVisible(false);
  startButton.setVisible(false);
  chrono = 0;
 

}

function end (player, enemy1,enemy2,enemy3,enemy4,enemy5,enemy6,enemy7,enemy8,enemy9,enemy10,enemy11,enemy12,enemy13,enemy14,enemy15,enemy16)
{
   this.physics.pause();
    player.setTint(0xff0000);
    //gameOver = true;
    
    naruto.stop();
    kira.play();
    chronoText.setText("Chrono: " + chrono);

end.setVisible(true);

//this.registry.destroy(); // destroy registry
//this.events.off(); // disable all active events
//this.scene.restart(); // restart current scene


}


function feu(player) {
  
  var vitesse;  
  if (direction == 'right') { vitesse = 0.4; }  
  
  var balle = tire.create(player.x , player.y, 'tire').setScale(0.1);
  

  
  balle.body.allowGravity =false;
 
  balle.setVelocity(1000 * vitesse, 0); 
  start.play();
  
}

function boum (tire, enemy1) {
  tire.destroy();
 enemy1.destroy();

}


function update(time, delta) {

  if (cursor.left.isDown) {
    //pour verifier dans la console si gauche fonctionne bien --> console.log("gauche");
    direction = 'left';
    player.setVelocityX(-250);
    player.setFlip(true, false);

  }

  if (cursor.right.isDown) {
    direction = 'right';
    player.setVelocityX(250);

    player.setFlip(false, false);
 
  }

  if (cursor.up.isDown) {

    player.setVelocityY(-250);

  }

  if (cursor.down.isDown) {

    player.setVelocityY(250);

  }


  if (cursor.right.isUp && cursor.left.isUp) {
    player.setVelocityX(0);
  }

  if (cursor.up.isUp && cursor.down.isUp) {
    player.setVelocityY(0);
  }
  if (Phaser.Input.Keyboard.JustDown(boumBouton)) {
    feu(player);
}


}




