// 

var config = {
    type: Phaser.AUTO,
    width: 1300,
    height: 500,
/*    physics: {
        default: 'arcade'
    },*/
    scene: {
        preload : preload,     
        create: create,     
        update : update   
    },

    physics : {
        default : "arcade",
        arcade : {
            debug : true,
            gravity : {y : 100}
        }
    }
}

const game = new Phaser.Game(config);

function preload() {
    //pour charger l'image this.load.image ; puis il faut 
    //donner une clés a cette immage <player> ; indiquer ou 
    //se trouve l'image
  this.load.image('player' ,'./assets/images/plane1.png');
  this.load.image('background' ,'./assets/images/background.png');
  this.load.image('obstacle1' ,'./assets/images/obstacle1.png');
  this.load.image('ground0' ,'./assets/images/ground0.png');
}

function create() {
 
 var backgroundImage = this.add.sprite(0,0,'background'); //pour afficher une image 
  backgroundImage.setOrigin(0.0) ;  /*pour ramener l'origine en haaut a gauche de la page definit*/
  //backgroundImage.setposition(config.width/2 , config.height/2);//pour centrer l'image 
  backgroundImage.setScale(1.7) ;   /*pour modofoer la taille de l'image*/

  // Ajout d'un perso sans physique --> var player = this.add.sprite(150,150,'player');


 var player = this.physics.add.sprite(25,60,'player');
 player.setScale(0.3);
 player.body.setSize(100,100);



  var platforms = this.physics.add.staticGroup();
  

  var ground0 = this.add.sprite(25,200,'ground0');
  ground0.setScale(0.75);

  var obstacle1 = this.physics.add.sprite(500,100,'obstacle1');
  obstacle1.setScale(0.3);
  obstacle1.body.setSize(100,100);


  platforms.add(obstacle1) ;
  platforms.add(ground0) ;

  this.physics.add.collider(platforms,player) ;

 
}

function update(time,delta) {
    
}
